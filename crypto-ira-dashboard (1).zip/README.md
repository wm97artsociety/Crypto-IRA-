# Crypto IRA Dashboard

This project is a cryptocurrency IRA dashboard featuring a high APR vault and an OKX bonus APR section integrated.

## Features

- Connect wallet via MetaMask
- View token balances with high interest rates (19,900%)
- OKX bonus APR fetching from backend API
- Responsive UI with React components
- Backend API proxy for OKX bonus APR

## Setup

1. Clone repo
2. Install dependencies `npm install`
3. Set your `.env` variables for OKX API (mocked here)
4. Run backend server: `npm run start`
5. Run frontend dev server with Vite (or your choice)
