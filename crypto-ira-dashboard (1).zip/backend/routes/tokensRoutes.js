const express = require('express');
const router = express.Router();
const { getOkxBonusAPR } = require('../controllers/tokensController');

router.get('/okx-bonus-apr', getOkxBonusAPR);

module.exports = router;
