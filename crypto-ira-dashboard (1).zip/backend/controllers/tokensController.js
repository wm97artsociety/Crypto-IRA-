const axios = require('axios');

const getOkxBonusAPR = async (req, res) => {
  try {
    // Simulated API call to OKX for bonus APR info
    // Replace with real API endpoint and authentication as needed
    const response = await axios.get('https://api.mock-okx.com/bonus/apr');
    const bonusAPR = response.data.bonusAPR || 0;
    res.json({ bonusAPR });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch OKX bonus APR' });
  }
};

module.exports = { getOkxBonusAPR };
