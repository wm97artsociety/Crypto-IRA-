const express = require('express');
const cors = require('cors');
const tokensRoutes = require('./routes/tokensRoutes');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.use('/api/tokens', tokensRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
