import React, { useState } from 'react';
import { Button } from './Button'; // Assuming you have a Button component

export default function OkxBonusSection() {
  const [bonusAPR, setBonusAPR] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchBonusAPR = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/tokens/okx-bonus-apr');
      const data = await res.json();
      if (res.ok) {
        setBonusAPR(data.bonusAPR);
      } else {
        setError(data.error || 'Failed to fetch bonus APR');
      }
    } catch (err) {
      setError('Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="okx-bonus-section p-4 border rounded bg-white shadow-md">
      <Button onClick={fetchBonusAPR} disabled={loading}>
        {loading ? 'Loading...' : 'Show OKX Bonus APR'}
      </Button>
      {bonusAPR !== null && (
        <p className="mt-2 font-semibold text-teal-700">
          OKX Bonus APR: {bonusAPR}%
        </p>
      )}
      {error && <p className="mt-2 text-red-600">{error}</p>}
    </div>
  );
}
