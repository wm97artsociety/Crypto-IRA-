import React from 'react';
import CryptoIRADashboard from './pages/CryptoIRADashboard';

export default function App() {
  return <CryptoIRADashboard />;
}
