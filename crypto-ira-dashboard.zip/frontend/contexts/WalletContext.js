// Wallet context provider
