// Sidebar component for hot tokens
