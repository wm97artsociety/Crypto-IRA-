// Solidity IRA contract
