// Interest rate manager
