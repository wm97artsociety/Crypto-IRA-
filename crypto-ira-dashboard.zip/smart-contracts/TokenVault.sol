// Token vault contract
