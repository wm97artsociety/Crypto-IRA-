import React, { useState, useEffect } from 'react';
import '../styles/CryptoFaucet.css';

const CryptoFaucet = () => {
  const [lastClaim, setLastClaim] = useState(null);
  const [cooldown, setCooldown] = useState(0);
  const [message, setMessage] = useState('');
  const [totalEarned, setTotalEarned] = useState(0);
  const [userCount, setUserCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCooldown(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleClaim = () => {
    const now = Date.now();
    if (!lastClaim || now - lastClaim >= 3600000) {
      setLastClaim(now);
      setCooldown(3600);
      setTotalEarned(prev => prev + 190);
      setUserCount(prev => prev + 1);
      setMessage('✅ You claimed $190 in crypto from the faucet!');
    } else {
      const timeLeft = 3600 - Math.floor((now - lastClaim) / 1000);
      setCooldown(timeLeft);
      setMessage('⏳ Please wait until the next hour to claim again.');
    }
  };

  return (
    <div className="faucet-container">
      <div className="faucet-box">
        <div className="faucet-header">
          <h2>💧 Crypto IRA Faucet</h2>
          <p>Claim $190 worth of crypto every hour from the trillion-dollar reserve.</p>
        </div>
        <div className="faucet-action">
          <button onClick={handleClaim} disabled={cooldown > 0}>
            {cooldown > 0 ? `Wait ${Math.floor(cooldown / 60)}m ${cooldown % 60}s` : 'Claim $190'}
          </button>
          <p className="message">{message}</p>
          <p>Total Earned: ${totalEarned}</p>
          <p>Users Funded: {userCount}</p>
        </div>
      </div>
    </div>
  );
};

export default CryptoFaucet;
