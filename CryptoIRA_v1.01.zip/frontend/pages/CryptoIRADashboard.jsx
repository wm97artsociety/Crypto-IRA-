import React from 'react';
import CryptoFaucet from '../components/CryptoFaucet';

const CryptoIRADashboard = () => {
  return (
    <div>
      <h1>Crypto IRA Dashboard</h1>
      <CryptoFaucet />
    </div>
  );
};

export default CryptoIRADashboard;
